#include <iostream>
using namespace std;

int main() {
    cout << "(14 >= 5) || ('A' > 'B') = " << ((14 >= 5) || ('A' > 'B')) << endl;


    cout << "(24 >= 35) || ('A' > 'B') = " << ((24 >= 35) || ('A' > 'B')) << endl;



    return 0;
}
