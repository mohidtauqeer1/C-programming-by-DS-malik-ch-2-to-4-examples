#include <iostream>
using namespace std;

int main() {
    int x=3;
    float y=15.6;
    cout << "x / 2 = " << x / 2  << endl;

    // Expression 2
    cout << "y / 2 + 5 = " << y / 2 + 5 << endl;

    // Expression 3
    cout << "4 + x / 2.0 = " << 4 + x / 2.0 << endl;


    return 0;
}
