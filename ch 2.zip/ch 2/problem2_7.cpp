#include <iostream>
using namespace std;
int main()
{
double x=2,
y=3;
cout <<12.8 * 17.5 - 34.50
 << endl;
cout <<x * 10.5 + y - 16.2 << endl;

return 0;
}