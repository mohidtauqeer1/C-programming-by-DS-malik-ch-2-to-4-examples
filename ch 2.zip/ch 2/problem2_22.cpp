#include <iostream> 
using namespace std; 
int main() 
{ 
int a, b; 
a = 65; b = 78; 
cout << "Hello there.\n"; 
cout << "a" << endl; 
cout << a << endl; 
cout << "b" << endl;
cout << b << endl; 
return 0; 
}