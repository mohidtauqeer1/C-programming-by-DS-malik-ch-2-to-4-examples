#include <iostream>
#include <string>
using namespace std;

int main() {
    string text = "Hello World";
    
    cout << "The string is:"<< text << endl;
    cout << "Length of the string: " << text.length() << endl;
    // we can use text.size to find the length of the strig

    return 0;
}
