#include <iostream>
using namespace std;
int main()
{
double divide,modulus;
divide = 5/2;
modulus = 34%5;
cout << "divide = " << divide << endl;
cout << "modulus = " << modulus << endl;
return 0;
}