#include <iostream>
using namespace std;
int main()
{
int x=2,
y=3,
z=4;
cout <<2 + 3 * 5 << endl;
cout <<3 + x - y / 7 << endl;
cout << x + 2 * (y - z) + 18 << endl;
return 0;
}


