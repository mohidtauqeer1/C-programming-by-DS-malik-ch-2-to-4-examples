#include <iostream>
using namespace std;
int main()
{
double first,conversion,counter,payrate;
first = 6.0;
conversion = 4.0;
payrate = 2;
 counter=3;
cout << "first = " << first << endl;
cout << "conversion = " << conversion << endl;
cout << "payrate = " << payrate << endl;
cout << "counter = " << counter << endl;
return 0;
}