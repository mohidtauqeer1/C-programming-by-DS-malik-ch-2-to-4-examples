// program show how arithmetic operation work
#include <iostream>
using namespace std;
int main()
{
cout<<"2+5= "<<2+5  << endl;
cout<<"2-5= "<<2-5  << endl;
cout<<"2*5= "<<2*5  << endl;
cout<<"5/2= "<<5/2  << endl;
cout<<"5%2= "<<5%2  << endl;
cout<<"2.0+5.0= "<<2.0+5.0  << endl;
cout<<"5.0-2.0 "<<5.0-2.0  << endl;
}