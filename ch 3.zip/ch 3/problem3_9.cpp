#include<iostream>
using namespace std;
int main()
{
    string name;
    cout<<"enter your name ";
    cin>>name;
    cin.clear();
     cout<<"enter your name ";
    cin>>name;
    cout<<name;
    return 0;
}